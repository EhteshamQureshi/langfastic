<?php

$dir = UBERMENU_DIR . 'pro/thirdparty/woocommerce/';

require_once $dir.'woocommerce.functions.php';
require_once $dir.'woocommerce.shortcodes.php';
require_once $dir.'woocommerce.itemlayouts.php';
require_once $dir.'woocommerce.settings.php';
require_once $dir.'woocommerce.item.settings.php';
require_once $dir.'woocommerce.customstyles.php';
